function route(pathname, handle) {
    console.log('The request from ' + pathname + ' was received in router');
    if (typeof handle[pathname] === 'function') {
        return handle[pathname]();
    } else {
        console.log('No request handle found for ' + pathname);
        return '404 NOT Found.';
    }
}

exports.route = route;
