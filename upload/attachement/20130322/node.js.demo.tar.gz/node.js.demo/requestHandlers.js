function index() {
    var out =
            '<style type="text/css">' +
                'ul li { padding: 5px 0px; }' +
            '</style>' +
            '<h2>welcome to use kkgoo test api.</h2>' +
            '<ul>' +

                '<li> 用户模块 ' +
                    '<ul>' +
                        '<li> 用户注册 </li> <a href="/api/user/register"> /api/user/register </a>' +
                    '</ul>' +
                '</li> ' +

                '<li> 测试模块 ' +
                    '<ul>' +
                        '<li> 测试结果 </li> <a href="/api/test/result"> /api/test/result </a>' +
                    '</ul>' +
                '</li> ' +

                '<li> 商品模块 ' +
                    '<ul>' +
                        '<li> 推荐商品 </li> <a href="/api/item/push"> /api/item/push </a>' +
                        '<li> 收藏商品 </li> <a href="/api/item/collect"> /api/item/collect </a>' +
                        '<li> 收藏商品列表 </li> <a href="/api/item/collections"> /api/item/collections </a>' +
                    '</ul>' +
                '</li> ' +

                '<li> 品牌模块 ' +
                    '<ul>' +
                        '<li> 所有品牌列表 </li> <a href="/api/brand/list?base=all"> /api/brand/list?base=all </a>' +
                        '<li> 用户关注品牌列表 </li> <a href="/api/brand/list?base=user"> /api/brand/list?base=user </a>' +
                        '<li> 获取某个品牌下的商品 </li> <a href="/api/brand/item"> /api/brand/item </a>' +
                    '</ul>' +
                '</li> ' +

            '</ul>';
    return out;
}

function sayHello() {
    var out = JSON.stringify({'name': 'luchanghong', 'code': 200});
    return out;
}

exports.index = index;
exports.sayHello = sayHello;

var userController = require('./controllers/user');
var testController = require('./controllers/test');
var itemController = require('./controllers/item');
var brandController = require('./controllers/brand');

exports.userController = userController;
exports.itemController = itemController;
exports.testController = testController;
exports.brandController = brandController;
