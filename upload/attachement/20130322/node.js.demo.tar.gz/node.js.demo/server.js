var http = require('http');
var url = require('url');

/*
http.createServer(function(request, response) {
    console.log('Starting ...');
    response.writeHead(200, {'Content-Type': 'text/plain'});
    response.write('Hello world!');
    response.end();
}).listen(9888);
*/

function startServer(route, handle) {
    function onRequest(request, response) {
        console.log('Start to response ...');

        // find the request pathname
        var pathname = url.parse(request.url).pathname;
        console.log('The current request pathname is ' + pathname);
        request.setEncoding("utf8");

        content = 
            '<html>' +
            '<head>' +
                '<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />' +
            '</head> <body>';

        content += route(pathname, handle);

        content += '</body> </html>';

        response.writeHead(200, {'Content-Type': 'text/html'});
        response.write(content);
        response.end();
    }

    http.createServer(onRequest).listen(9888);
    console.log('It has started.');
}

exports.start = startServer;
