var server = require('./server');
var router = require('./router');
var requestHandlers = require('./requestHandlers');

var handle = {};
handle['/'] = requestHandlers.index;
handle['/api/user/register'] = requestHandlers.userController.register;
handle['/api/test/result'] = requestHandlers.testController.result;
handle['/api/item/push'] = requestHandlers.itemController.push;
handle['/api/item/collect'] = requestHandlers.itemController.collect;
handle['/api/item/collections'] = requestHandlers.itemController.collections;
handle['/api/brand/list'] = requestHandlers.brandController.list;
handle['/api/brand/item'] = requestHandlers.brandController.item;

server.start(router.route, handle);
