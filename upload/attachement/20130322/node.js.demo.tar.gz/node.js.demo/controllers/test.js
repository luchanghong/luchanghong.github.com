function result() {
    var res =
    {
        code: 200,
        data: [
            {
                id: 1,
                name: 'MMJ',
                description: 'MMJ is a great brand',
                img: 'http://www.kkgoo.com/xxx.jpg'
            },
            {
                id: 2,
                name: 'sada',
                description: 'sdMJ is a great brand',
                img: 'http://www.kkgoo.com/xxx.jpg'
            },
            {
                id: 3,
                name: 'thirf',
                description: 'sdMJ is a great brand',
                img: 'http://www.kkgoo.com/xxx.jpg'
            }
        ]
    };

    return JSON.stringify(res);
}

exports.result = result
