function register() {
    var res =
    {
        data: 1,
        code: 200
    };

    return JSON.stringify(res);
}

exports.register = register;
