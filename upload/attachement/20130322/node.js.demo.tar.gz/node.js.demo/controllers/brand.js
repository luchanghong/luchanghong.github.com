function list() {
    var res =
    {
        data: [
            {
                id: 1,
                name: 'xxx',
                description: 'nb brand',
                img: 'http://221323.jpg'
            },
            {
                id: 2,
                name: 'brand 2',
                description: 'nb brand',
                img: 'http://221323.jpg'
            },
            {
                id: 3,
                name: 'brand4',
                description: 'nb brand',
                img: 'http://221323.jpg'
            }
        ],
        code: 200
    };

    return JSON.stringify(res);
}

function item() {
    var res =
    {
        data: [
            {
                id: 1,
                title: '时尚t恤你值得拥有',
                picture: 'http://aadsa/dada.jpg',
                buy_url: 'http://adad.jpg'
            },
            {
                id: 2,
                title: '时尚t恤你值得拥有',
                picture: 'http://aadsa/dada.jpg',
                buy_url: 'http://adad.jpg'
            }
        ],
        code: 200
    };

    return JSON.stringify(res);
}

exports.list = list;
exports.item = item;
