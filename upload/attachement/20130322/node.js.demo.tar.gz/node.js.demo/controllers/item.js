function push() {
    var res =
    {
        data: [
            {
                id: 1,
                title: '时尚t恤你值得拥有',
                picture: 'http://aadsa/dada.jpg',
                price: "100000",
                buy_url: 'http://adad.jpg',
                cat_name: 't恤',
                brand: {
                    id: 1,
                    name: 'mastermind',
                    description: '很好的牌子',
                    img: 'http://sadasd/ad.jpg',
                    comment: {
                        uid: 23,
                        uname: 'Disk',
                        uinfo: '我是',
                        mark: '5',
                        content: 'KOL品论内容'
                    }
                }
            },
            {
                id: 2,
                title: '时尚t恤你值得拥有',
                picture: 'http://aadsa/dada.jpg',
                price: "100000",
                buy_url: 'http://adad.jpg',
                cat_name: 't恤',
                brand: {
                    id: 1,
                    name: 'mastermind',
                    description: '很好的牌子',
                    img: 'http://sadasd/ad.jpg',
                    comment: {
                        uid: 23,
                        uname: 'Disk',
                        uinfo: '我是',
                        mark: '5',
                        content: 'KOL品论内容'
                    }
                }
            }
        ],
        code: 200
    };

    return JSON.stringify(res);
}

function collect() {
    var res = { code: 200 };
    return JSON.stringify(res);
}

function collections() {
    var res =
    {
        data: {
            item_list: [
                {
                    id: 1,
                    title: '时尚t恤你值得拥有',
                    picture: 'http://aadsa/dada.jpg',
                    buy_url: 'http://adad.jpg'
                },
                {
                    id: 2,
                    title: '时尚t恤你值得拥有',
                    picture: 'http://aadsa/dada.jpg',
                    buy_url: 'http://adad.jpg'
                }
            ],
            total: 100
        },
        code: 200
    };

    return JSON.stringify(res);
}
exports.push = push;
exports.collect = collect;
exports.collections = collections;
