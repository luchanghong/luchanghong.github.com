//
//  Person.h
//  classProperty
//
//  Created by lch on 13-2-1.
//  Copyright (c) 2013年 lch. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Person : NSObject
{
    NSString *name;
}
@property (nonatomic) NSInteger age;
@property (nonatomic, weak) NSString *gender;
-(Person *)init;
-(NSString *)name;
-(void)setName: (NSString *)n;
@end