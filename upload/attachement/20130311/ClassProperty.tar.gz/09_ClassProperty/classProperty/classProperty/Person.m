//
//  Person.m
//  classProperty
//
//  Created by lch on 13-2-1.
//  Copyright (c) 2013年 lch. All rights reserved.
//

#import "Person.h"

@implementation Person
// @synthesize age;
// @synthesize gender;
// @synthesize age,gender;

-(Person *)init
{
    self = [super init];
    self.age = 2;
    self.name = @"ssss";
    self.gender = @"male";
    // self->age = 24;
    return self;
}
-(NSString *)name
{
    return name;
}

-(void)setName:(NSString *)n
{
    name = n;
}
@end
