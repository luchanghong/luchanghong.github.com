//
//  main.m
//  classProperty
//
//  Created by lch on 13-2-1.
//  Copyright (c) 2013年 lch. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Person.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        Person *person = [[Person alloc] init];
        
        NSLog(@"%@ person's name is %@, and age is %ld.", person.gender, person.name, person.age);
        
        person.name = @"luchanghong";
        // [person setName: @"luchanghong"];
        person.gender = @"female";
        person.age = 25;
        NSLog(@"%@ person's name is %@, and age is %ld.", person.gender, person.name, person.age);

        
        // insert code here...
        NSLog(@"Hello, World!");
        
    }
    return 0;
}

