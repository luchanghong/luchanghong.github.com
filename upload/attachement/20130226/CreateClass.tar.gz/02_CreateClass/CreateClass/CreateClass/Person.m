//
//  Person.m
//  CreateClass
//
//  Created by lch on 13-1-23.
//  Copyright (c) 2013年 lch. All rights reserved.
//

#import "Person.h"

@implementation Person

-(void) printPersnalInfor
{
    NSLog(@"Hey, i am a %@. \n My name is %@ and i am %d years old.", sex, name, age);
}

-(void) setAge: (int) myAge setSex: (NSString *) mySex
{
    self->age = myAge;
    // age = myAge;
    sex = mySex;
}

-(void) setName: (NSString *) MyName
{
    name = MyName;
}

@end