//
//  Student.m
//  CreateClass
//
//  Created by lch on 13-1-23.
//  Copyright (c) 2013年 lch. All rights reserved.
//

#import "Student.h"

@implementation Student

-(void) printStdInfo
{
    NSLog(@"I am a student, and I am a %@, then my name is %@.", stdSex, stdName);
}

-(Student *) initWithSexAndName:(NSString *)s setName:(NSString *)n
{
    self = [super init];
    
    if (self) {
        self->stdSex = s;
        self->stdName = n;
    }
    return self;
}

-(NSString *) stdSex
{
    return stdSex;
}

-(NSString *) stdName
{
    return stdName;
}
@end