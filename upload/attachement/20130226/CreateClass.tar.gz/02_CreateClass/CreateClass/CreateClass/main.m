//
//  main.m
//  CreateClass
//
//  Created by lch on 13-1-23.
//  Copyright (c) 2013年 lch. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Person.h"
#import "Student.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        // use person class
        Person *person = [[Person alloc] init];
        [person setAge:24 setSex: @"male"];
        [person setName: @"luchanghong"];
        [person printPersnalInfor];
        
        Student *student = [[Student alloc] initWithSexAndName: @"boy" setName:@"Changhong Lu"];
        [student printStdInfo];
        
        NSString *curSex = [student stdSex];
        NSString *curName = [student stdName];
        NSLog(@"The current sex is %@ and the current name is %@", curSex, curName);
        
        // insert code here...
        NSLog(@"i am learning how to create a class now.");

    }
    return 0;
}