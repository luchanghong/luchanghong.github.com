//
//  Person.h
//  CreateClass
//
//  Created by lch on 13-1-23.
//  Copyright (c) 2013年 lch. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Person : NSObject
{
    int age;
    NSString *sex;
    NSString *name;
}

// define some messages(methods)
-(void) printPersnalInfor;
-(void) setAge: (int) myAge setSex: (NSString *) mySex;
-(void) setName: (NSString *) MyName;
@end