//
//  Student.h
//  CreateClass
//
//  Created by lch on 13-1-23.
//  Copyright (c) 2013年 lch. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Student : NSObject
{
    NSString *stdSex;
    NSString *stdName;
}
-(void) printStdInfo;
-(Student *) initWithSexAndName: (NSString *) s setName: (NSString *) n;
-(NSString *) stdSex;
-(NSString *) stdName;
@end
