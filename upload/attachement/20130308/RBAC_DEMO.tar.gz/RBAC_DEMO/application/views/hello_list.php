lists:
<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>mail</th>
        </tr>
    </thead>

    <tbody>
        <?php foreach ($lists as $key=>$val): ?>
            <tr>
                <td> <?=$key+1;?> </td>
                <td> <?=$val->uname;?> </td>
                <td> <?=$val->email;?> </td>
            </tr>
        <?php endforeach;?>
    </tbody>
</table>
