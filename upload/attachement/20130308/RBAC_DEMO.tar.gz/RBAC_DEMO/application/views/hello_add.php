<form method="post" action="/hello/insert">
    UserName: <input type="text" name="uname">
    E-mail:   <input type="text" name="email">
    <input type="submit" value="Submit">
</form>
