
<p style="color:red;"> <?php=$desc;?> </p>
<ul>
<?php foreach($list as $key=>$val):?>
    <li><?=$val?></li>
<?php endforeach;?>
<ul>
