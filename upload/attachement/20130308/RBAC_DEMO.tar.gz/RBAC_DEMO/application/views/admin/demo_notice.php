<h1><img src="img/icons/warning.png" alt="" /> Notifications</h1>

<div class="notif success bloc">
    <strong>Success :</strong> Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. 
    <a href="#" class="close">x</a>
</div>
<div class="notif error bloc">
    <strong>Error :</strong> Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.
    <a href="#" class="close">x</a>
</div>
<div class="notif warning bloc">
    <strong>Warning !</strong> Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. 
    <a href="#" class="close">x</a>
</div>
<div class="notif info bloc">
    <strong>Information :</strong> Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. 
    <a href="#" class="close">x</a>
</div>
<div class="notif tip bloc">
    <strong>Tips :</strong> Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. 
    <a href="#" class="close">x</a>
</div>


<div class="bloc">
    <div class="title">Notification inside a bloc</div>
    <div class="content">
        <div class="notif success">
            <strong>Success :</strong> Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. 
            <a href="#" class="close">x</a>
        </div>
        <div class="notif error">
            <strong>Error :</strong> Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.
            <a href="#" class="close">x</a>
        </div>
        <div class="notif warning">
            <strong>Warning !</strong> Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. 
            <a href="#" class="close">x</a>
        </div>
        <div class="notif info">
            <strong>Information :</strong> Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. 
            <a href="#" class="close">x</a>
        </div>
        <div class="notif tip">
            <strong>Tips :</strong> Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. 
            <a href="#" class="close">x</a>
        </div>
    </div>
</div>
