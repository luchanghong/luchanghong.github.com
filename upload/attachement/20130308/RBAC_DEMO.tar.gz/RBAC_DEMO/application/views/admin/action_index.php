<style type="text/css">
    td { line-height: 20px; }
</style>
<h1> <?php echo $title;?> </h1>
<div class="bloc">
    <div class="title"> <?php echo $subtitle;?> </div>
    <div class="content">
        <table cellpadding="0" cellspacing="0">
            <thead>
                <tr>
                    <th> ID </th>
                    <th> 操作名称 </th>
                    <th> 链接地址 </th>
                    <th> 验证字符 </th>
                    <th> 菜单中显示 </th>
                    <th> 排序 </th>
                    <th> 操作 </th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($act as $val) {
                    echo "<tr>";
                    echo genTableCell($val);
                    echo "</tr>";
                    if ( !empty($val['subact']) ) {
                        foreach ( $val['subact'] as $subval ) {
                            echo "<tr>";
                            echo genTableCell($subval, '__');
                            echo "</tr>";
                        }
                    }
                }?>
            </tbody>
        </table>
    </div>
</div>
<?php
function genTableCell($val, $indent = '') {
    $val['title'] = $indent ? $indent.' '.$val['title'] : "<img src=\"img/icons/menu/dark/{$val['icon']}\"><strong>{$val['title']}</strong>";
    $cell = "<td> {$val['id']} </td>";
    $cell .= "<td> {$val['title']} </td>";
    $cell .= "<td> {$val['target']} </td>";
    $cell .= "<td> {$val['verify']} </td>";
    $cell .= "<td> {$val['display']} </td>";
    $cell .= "<td> {$val['orderby']} </td>";
    $cell .= '<td class="actions"><a href="/admin/action/edit/'.$val['id'].'" title="编辑"><img src="img/icons/actions/edit.png" alt="" /></a>
        <a href="/admin/action/delete/'.$val['id'].'" title="删除" onclick="return confirm(\'确认删除？\');"><img src="img/icons/actions/delete.png" ></a></td>';
    return $cell;
}
?>
