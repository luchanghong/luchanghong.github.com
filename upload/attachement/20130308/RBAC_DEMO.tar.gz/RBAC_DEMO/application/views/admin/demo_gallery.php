<h1><img src="img/icons/pictures.png" alt="" /> Gallery</h1>
<div class="bloc">
    <div class="title">Picture Gallery</div>
    <div class="content">
        <p>You can have gallery inside a block our outside</p>
        <ul class="gallery">
                        <li>
                <a href="#"><img src="http://lorempixum.com/120/80/food/0" alt=""/></a>
                <span class="info">Image name</span>
                <a href="#" title="delete Image" class="del">Delete</a>
                <a href="#" class="over"><span>Edit this image</span></a>
                <a href="http://lorempixum.com/800/600/food/0?.jpg" class="large zoombox" title="full-size">Enlarge</a>
            </li>
                        <li>
                <a href="#"><img src="http://lorempixum.com/120/80/food/1" alt=""/></a>
                <span class="info">Image name</span>
                <a href="#" title="delete Image" class="del">Delete</a>
                <a href="#" class="over"><span>Edit this image</span></a>
                <a href="http://lorempixum.com/800/600/food/1?.jpg" class="large zoombox" title="full-size">Enlarge</a>
            </li>
                        <li>
                <a href="#"><img src="http://lorempixum.com/120/80/food/2" alt=""/></a>
                <span class="info">Image name</span>
                <a href="#" title="delete Image" class="del">Delete</a>
                <a href="#" class="over"><span>Edit this image</span></a>
                <a href="http://lorempixum.com/800/600/food/2?.jpg" class="large zoombox" title="full-size">Enlarge</a>
            </li>
                        <li>
                <a href="#"><img src="http://lorempixum.com/120/80/food/3" alt=""/></a>
                <span class="info">Image name</span>
                <a href="#" title="delete Image" class="del">Delete</a>
                <a href="#" class="over"><span>Edit this image</span></a>
                <a href="http://lorempixum.com/800/600/food/3?.jpg" class="large zoombox" title="full-size">Enlarge</a>
            </li>
                        <li>
                <a href="#"><img src="http://lorempixum.com/120/80/food/4" alt=""/></a>
                <span class="info">Image name</span>
                <a href="#" title="delete Image" class="del">Delete</a>
                <a href="#" class="over"><span>Edit this image</span></a>
                <a href="http://lorempixum.com/800/600/food/4?.jpg" class="large zoombox" title="full-size">Enlarge</a>
            </li>
                        <li>
                <a href="#"><img src="http://lorempixum.com/120/80/food/5" alt=""/></a>
                <span class="info">Image name</span>
                <a href="#" title="delete Image" class="del">Delete</a>
                <a href="#" class="over"><span>Edit this image</span></a>
                <a href="http://lorempixum.com/800/600/food/5?.jpg" class="large zoombox" title="full-size">Enlarge</a>
            </li>
                        <li>
                <a href="#"><img src="http://lorempixum.com/120/80/food/6" alt=""/></a>
                <span class="info">Image name</span>
                <a href="#" title="delete Image" class="del">Delete</a>
                <a href="#" class="over"><span>Edit this image</span></a>
                <a href="http://lorempixum.com/800/600/food/6?.jpg" class="large zoombox" title="full-size">Enlarge</a>
            </li>
                        <li>
                <a href="#"><img src="http://lorempixum.com/120/80/food/7" alt=""/></a>
                <span class="info">Image name</span>
                <a href="#" title="delete Image" class="del">Delete</a>
                <a href="#" class="over"><span>Edit this image</span></a>
                <a href="http://lorempixum.com/800/600/food/7?.jpg" class="large zoombox" title="full-size">Enlarge</a>
            </li>
                        <li>
                <a href="#"><img src="http://lorempixum.com/120/80/food/8" alt=""/></a>
                <span class="info">Image name</span>
                <a href="#" title="delete Image" class="del">Delete</a>
                <a href="#" class="over"><span>Edit this image</span></a>
                <a href="http://lorempixum.com/800/600/food/8?.jpg" class="large zoombox" title="full-size">Enlarge</a>
            </li>
                        <li>
                <a href="#"><img src="http://lorempixum.com/120/80/food/9" alt=""/></a>
                <span class="info">Image name</span>
                <a href="#" title="delete Image" class="del">Delete</a>
                <a href="#" class="over"><span>Edit this image</span></a>
                <a href="http://lorempixum.com/800/600/food/9?.jpg" class="large zoombox" title="full-size">Enlarge</a>
            </li>
                    </ul>
        <div class="cb"></div>
    </div>
</div>


<ul class="gallery">
        <li>
        <a href="#"><img src="http://lorempixum.com/120/80/food/0" alt=""/></a>
        <span class="info">Image name</span>
        <a href="#" title="delete Image" class="del">Delete</a>
        <a href="#" class="over"><span>Edit this image</span></a>
        <a href="http://lorempixum.com/800/600/food/0?.jpg" class="large zoombox" title="full-size">Enlarge</a>
    </li>
        <li>
        <a href="#"><img src="http://lorempixum.com/120/80/food/1" alt=""/></a>
        <span class="info">Image name</span>
        <a href="#" title="delete Image" class="del">Delete</a>
        <a href="#" class="over"><span>Edit this image</span></a>
        <a href="http://lorempixum.com/800/600/food/1?.jpg" class="large zoombox" title="full-size">Enlarge</a>
    </li>
        <li>
        <a href="#"><img src="http://lorempixum.com/120/80/food/2" alt=""/></a>
        <span class="info">Image name</span>
        <a href="#" title="delete Image" class="del">Delete</a>
        <a href="#" class="over"><span>Edit this image</span></a>
        <a href="http://lorempixum.com/800/600/food/2?.jpg" class="large zoombox" title="full-size">Enlarge</a>
    </li>
        <li>
        <a href="#"><img src="http://lorempixum.com/120/80/food/3" alt=""/></a>
        <span class="info">Image name</span>
        <a href="#" title="delete Image" class="del">Delete</a>
        <a href="#" class="over"><span>Edit this image</span></a>
        <a href="http://lorempixum.com/800/600/food/3?.jpg" class="large zoombox" title="full-size">Enlarge</a>
    </li>
        <li>
        <a href="#"><img src="http://lorempixum.com/120/80/food/4" alt=""/></a>
        <span class="info">Image name</span>
        <a href="#" title="delete Image" class="del">Delete</a>
        <a href="#" class="over"><span>Edit this image</span></a>
        <a href="http://lorempixum.com/800/600/food/4?.jpg" class="large zoombox" title="full-size">Enlarge</a>
    </li>
        <li>
        <a href="#"><img src="http://lorempixum.com/120/80/food/5" alt=""/></a>
        <span class="info">Image name</span>
        <a href="#" title="delete Image" class="del">Delete</a>
        <a href="#" class="over"><span>Edit this image</span></a>
        <a href="http://lorempixum.com/800/600/food/5?.jpg" class="large zoombox" title="full-size">Enlarge</a>
    </li>
        <li>
        <a href="#"><img src="http://lorempixum.com/120/80/food/6" alt=""/></a>
        <span class="info">Image name</span>
        <a href="#" title="delete Image" class="del">Delete</a>
        <a href="#" class="over"><span>Edit this image</span></a>
        <a href="http://lorempixum.com/800/600/food/6?.jpg" class="large zoombox" title="full-size">Enlarge</a>
    </li>
        <li>
        <a href="#"><img src="http://lorempixum.com/120/80/food/7" alt=""/></a>
        <span class="info">Image name</span>
        <a href="#" title="delete Image" class="del">Delete</a>
        <a href="#" class="over"><span>Edit this image</span></a>
        <a href="http://lorempixum.com/800/600/food/7?.jpg" class="large zoombox" title="full-size">Enlarge</a>
    </li>
        <li>
        <a href="#"><img src="http://lorempixum.com/120/80/food/8" alt=""/></a>
        <span class="info">Image name</span>
        <a href="#" title="delete Image" class="del">Delete</a>
        <a href="#" class="over"><span>Edit this image</span></a>
        <a href="http://lorempixum.com/800/600/food/8?.jpg" class="large zoombox" title="full-size">Enlarge</a>
    </li>
        <li>
        <a href="#"><img src="http://lorempixum.com/120/80/food/9" alt=""/></a>
        <span class="info">Image name</span>
        <a href="#" title="delete Image" class="del">Delete</a>
        <a href="#" class="over"><span>Edit this image</span></a>
        <a href="http://lorempixum.com/800/600/food/9?.jpg" class="large zoombox" title="full-size">Enlarge</a>
    </li>
    </ul>

<div class="cb"></div>
