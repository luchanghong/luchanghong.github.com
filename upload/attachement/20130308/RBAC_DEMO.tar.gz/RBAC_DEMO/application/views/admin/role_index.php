<style type="text/css">
    td { line-height: 20px; }
</style>
<h1> <?php echo $title;?> </h1>
<div class="bloc">
    <div class="title"> <?php echo $subtitle;?> </div>
    <div class="content">
        <table cellpadding="0" cellspacing="0">
            <thead>
                <tr>
                    <th > ID </th>
                    <th > 角色名称 </th>
                    <th > 权限内容 </th>
                    <th > 操作 </th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($roles as $val) {
                    echo "<tr>";
                    echo "<td> {$val['id']} </td>";
                    echo "<td> {$val['name']} </td>";
                    echo "<td> ".list_act($val['act'])." </td>";
                    echo '<td class="actions"><a href="/admin/role/edit/'.$val['id'].'" title="编辑"><img src="img/icons/actions/edit.png" /></a>
                        <a href="/admin/role/delete/'.$val['id'].'" title="删除" onclick="return confirm(\'确认删除？\');"><img src="img/icons/actions/delete.png" ></a></td>';
                    echo "</tr>";
                }?>
            </tbody>
        </table>
    </div>
</div>
<?php
    function list_act($act)
    {
        $arr = unserialize($act);
        return implode(',', $arr);
    }
?>
