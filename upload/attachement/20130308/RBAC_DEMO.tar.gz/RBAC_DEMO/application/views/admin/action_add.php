<?php
$icon_arr = listActionIcon();
?>
<h1> <?php echo $title;?> </h1>
<div class="bloc">
    <div class="title"> <?php echo $subtitle;?> </div>
    <div class="content">
        <form action="" method="post">
            <div class="input">
                <label for="input1">操作名称</label>
                <input type="text" name="title" value="<?php echo $act['title'];?>"> <br>
            </div>

            <div class="input">
                <label for="input1">icon图标</label>
            <?php foreach ( $icon_arr as $key=>$icon ) {
                $checked = $icon == $act['icon'] ? 'checked' : '';
                echo "<input name=\"icon\" type=\"radio\" value=\"{$icon}\" {$checked}> <img src=\"img/icons/menu/dark/{$icon}\" style=\"margin-right:20px;\"> ";
                if ( ($key+1)%5 == 0 ) { echo "<br>"; }
            }?>
            </div>

            <div class="input">
                <label for="input1">链接地址</label>
                <input type="text" name="target" value="<?php echo $act['target'];?>"> <br>
            </div>

            <div class="input">
                <label for="input1">验证字符</label>
                <input type="text" name="verify" value="<?php echo $act['verify'];?>"> <br>
            </div>

            <div class="input">
                <label for="input1">父级操作</label>
                <select name="pid">
                    <option value="0"> 顶级操作 </option>
                    <?php foreach ( $top_act as $val ) {
                        if ( $val['id'] == $act['id'] ) { continue; }
                        $selected = $val['id'] == $act['pid'] ? 'selected' : '';
                        echo "<option value=\"{$val['id']}\" {$selected}> {$val['title']} </option>";
                    }?>
                </select>
            </div>

            <div class="input">
                <label for="input1">是否显示</label>
                <input type="radio" name="display" value="yes" <?php echo $act['display'] == 'yes' ? 'checked' : '';?>> YES &nbsp;&nbsp;&nbsp;&nbsp;
                <input type="radio" name="display" value="no" <?php echo $act['display'] == 'no' ? 'checked' : '';?>> NO
            </div>

            <div class="input">
                <label for="input1">排序</label>
                <input type="text" name="orderby" value="<?php echo $act['orderby'];?>"> <br>
            </div>

            <div class="submit clear">
                <input type="submit" name="submit" value="提交">
            </div>
        </form>
    </div>
</div>
