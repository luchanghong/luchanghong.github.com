<!DOCTYPE html>
<html>
    <head>
        <base href="<?php echo base_url();?>">
        <title>Your Admin Panel</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>

        <link rel="stylesheet" href="css/style.css" />
        <link rel="stylesheet" href="js/jwysiwyg/jquery.wysiwyg.old-school.css" />

        <!-- jQuery AND jQueryUI -->
        <script type="text/javascript" src="js/jquery.min.js"></script>
        <script type="text/javascript" src="js/jquery-ui.min.js"></script>
        <script type="text/javascript" src="js/min.js"></script>
        
    </head>
    <body>
                
            <div id="content" class="login">
                
                <h1><img src="img/icons/lock-closed.png" alt="" /> Admin Panel, Just Try This ! </h1>
                
                
                <div class="notif tip">
                    No password needed just submit the form
                    <a href="#" class="close">X</a>
                </div>
                <form action="admin/account/login">

                <div class="input placeholder">
                    <label for="login">Login</label>
                    <input type="text" id="login"/>
                </div>
                <div class="input placeholder">
                    <label for="pass">Password</label>
                    <input type="password" id="pass" value=""/>
                </div>
                <div class="checkbox">
                    <input type="checkbox" id="remember"/>
                    <label class="inline" for="remember">Remember me</label>
                </div>
                <div class="submit">
                    <input type="submit" value="Login me in"/>
                </div>
                </form>

                
            </div>
        
        
    </body>
</html>

