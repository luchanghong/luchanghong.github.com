<h1> <?php echo $title;?> </h1>
<div class="bloc">
    <div class="title"> <?php echo $subtitle;?> </div>
    <div class="content">
        <form action="" method="post">
            <div class="input">
                <label for="input1">角色名称</label>
                <input type="text" name="roleName" value="<?php echo $role['name'];?>"> <br>
                请填写角色的名称，如：高级写手
            </div>

            <div class="input">
                <label for="input2">权限分配</label>
                <table>
                <?php foreach ($act as $key=>$val) {
                    echo '<tr><td> <strong>'.$val['title'].'</strong> </td><td>';
                    foreach ($val['subact'] as $k=>$value) {
                        $checkbox = '<label for="iphonecheck" class="inline">'.$value['title'].'</label>';
                        $checkbox .= '<input type="checkbox" name="roleAct[]" class="iphone"';
                        $checkbox .= @in_array($value['id'], unserialize($role['act'])) ? ' checked' : '';
                        $checkbox .= ' value="'.$value['id'].'">';
                        echo "<div class=\"left\" style=\"padding:5px 0;width:25%\">{$checkbox}</div>";
                    }
                    echo "</td></tr>";
                } ?>
                </table>
            </div>

            <div class="submit clear">
                <br> <br>
                <input type="submit" name="submit" value="提交">
            </div>
        </form>
    </div>
</div>
