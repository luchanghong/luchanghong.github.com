<ul>
    <?php foreach($menu as $key=>$val):?>
        <li> <a href=<?=$val;?> > <?=$key;?> </a> </li>
    <?php endforeach;?>
</ul>
