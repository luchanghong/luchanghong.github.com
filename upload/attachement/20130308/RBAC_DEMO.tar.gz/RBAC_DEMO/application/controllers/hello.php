<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Hello extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
        echo 'Hello';
        $this->menu();
	}

    protected function menu()
    {
        $data = array(
            'menu' => array(
                'message list' => '/hello/lists',
                'message add'  => '/hello/add',
            ),
        );
        $this->load->view('hello_menu', $data);
    }

    public function message()
    {
        $this->menu();
    }

    public function lists(){
        $this->load->database();
        $this->load->model('Hello_model', 'hello');
        $data['lists'] = $this->hello->get_message_list();
        $this->load->view('hello_list', $data);
    }

    public function add()
    {
        $this->load->view('hello_add');
        $this->output->cache(1);
    }

    function insert(){
        $this->load->model('Hello_model', 'hello', TRUE);
        print_r($_POST);
        $this->hello->insert_message();
        // echo "insert Ok!";
    }

    // This blow is just for test.
    public function any()
    {
        // echo 'This is any function';
        $hello_var = array(
            'desc' => 'I am a test var',
            'list' => array(1,2,3,4),
        );
        $this->load->view('hello_any');
        $this->load->view('hello_var', $hello_var);
    }
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
