<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Action extends CI_Controller {
    function __construct()
    {
        parent::__construct();
        $this->load->library('AdminAction');
    }

    function index()
    {
        $this->adminaction->act_verify = 'ACTION_LIST';
        $this->adminaction->checkCurrentAction();
        $data = array(
            'title'=>'操作管理',
            'subtitle'=>'操作列表',
        );
        $data['act'] = $this->adminaction->getAllAdminActions();
        $main = $this->load->view('admin/action_index', $data, true);
        $this->load->view('admin/index', array('content'=>$main));
    }

    function edit($id)
    {
        $this->adminaction->act_verify = 'ACTION_EDIT';
        $this->adminaction->checkCurrentAction();
        $id = isLegalId($id);
         
        // for save
        if ( $this->input->post('submit') ) {
            $save_data = array(
                'pid'=>$this->input->post('pid'),
                'icon'=>$this->input->post('icon'),
                'title'=>$this->input->post('title'),
                'target'=>$this->input->post('target'),
                'verify'=>$this->input->post('verify'),
                'display'=>$this->input->post('display'),
                'orderby'=>$this->input->post('orderby'),
            );
            $this->db->where('id', $id);
            $this->db->update('admin_action', $save_data);
            header('Location: /admin/action/index');
        }

        $data = array(
            'title'=>'操作管理',
            'subtitle'=>'操作编辑',
        );
        $data['act'] = $this->adminaction->getActionInfo($id);
        $data['top_act'] = $this->adminaction->getAllAdminActions();
        $main = $this->load->view('admin/action_add', $data, true);
        $this->load->view('admin/index', array('content'=>$main));
    }

    function add()
    {
        $this->adminaction->act_verify = 'ACTION_ADD';
        $this->adminaction->checkCurrentAction();
        // for save
        if ( $this->input->post('submit') ) {
            $save_data = array(
                'pid'=>$this->input->post('pid'),
                'icon'=>$this->input->post('icon'),
                'title'=>$this->input->post('title'),
                'target'=>$this->input->post('target'),
                'verify'=>$this->input->post('verify'),
                'display'=>$this->input->post('display'),
                'orderby'=>$this->input->post('orderby'),
            );
            $this->db->insert('admin_action', $save_data);
            header('Location: /admin/action/index');
        }

        $data = array(
            'title'=>'操作管理',
            'subtitle'=>'添加操作',
        );
        $data['act'] = array('title'=>'', 'icon'=>'', 'target'=>'', 'verify'=>'', 'display'=>'', 'orderby'=>'');
        $data['top_act'] = $this->adminaction->getAllAdminActions();
        $main = $this->load->view('admin/action_add', $data, true);
        $this->load->view('admin/index', array('content'=>$main));
    }

    function delete($id)
    {
        $this->adminaction->act_verify = 'ACTION_DELETE';
        $this->adminaction->checkCurrentAction();
        $id = isLegalId($id);
        $this->db->where('id', $id);
        $this->db->or_where('pid', $id);
        $this->db->delete('admin_action');

        header('Location: /admin/action/index');
    }
}
