<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Demo extends CI_Controller {
    function __construct()
    {
        parent::__construct();
        $this->load->library('AdminAction');
    }

    function index()
    {
        $data = array();
        $main = $this->load->view('admin/demo_', $data, TRUE);
        $this->load->view('admin/index', array('content'=>$main));
    }

    function form()
    {
        $data = array();
        $main = $this->load->view('admin/demo_form', $data, TRUE);
        $this->load->view('admin/index', array('content'=>$main));
    }

    function table()
    {
        $data = array();
        $main = $this->load->view('admin/demo_table', $data, TRUE);
        $this->load->view('admin/index', array('content'=>$main));
    }

    function tab()
    {
        $data = array();
        $main = $this->load->view('admin/demo_tab', $data, TRUE);
        $this->load->view('admin/index', array('content'=>$main));
    }

    function gallery()
    {
        $data = array();
        $main = $this->load->view('admin/demo_gallery', $data, TRUE);
        $this->load->view('admin/index', array('content'=>$main));
    }

    function notice()
    {
        $data = array();
        $main = $this->load->view('admin/demo_notice', $data, TRUE);
        $this->load->view('admin/index', array('content'=>$main));
    }

    function chart()
    {
        $data = array();
        $main = $this->load->view('admin/demo_chart', $data, TRUE);
        $this->load->view('admin/index', array('content'=>$main));
    }
}
