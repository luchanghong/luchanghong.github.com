<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Account extends CI_Controller {
    function __construct()
    {
        parent::__construct();
    }

    function index()
    {
    }

    function login()
    {
        /*
         * TODO: select $_POST information in admin_user table to get admin_id
         */
        $admin_id = 1;
        $this->session->set_userdata('admin_id', $admin_id);
        header('Location: /admin/index');
    }

    function logout()
    {
        $this->session->sess_destroy();
        header('Location: /admin');
    }
}
