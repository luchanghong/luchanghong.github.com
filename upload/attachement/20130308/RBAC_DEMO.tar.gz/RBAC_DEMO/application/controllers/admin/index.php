<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Index extends CI_Controller {
    function __construct()
    {
        parent::__construct();
        $this->load->library('AdminAction');
    }

    function index()
    {
        $this->adminaction->act_verify = 'ADMIN_INDEX';
        $this->adminaction->checkCurrentAction();
        $data = array();
        $main = $this->load->view('admin/index_main', $data, TRUE);
        $this->load->view('admin/index', array('content'=>$main));
    }

}
