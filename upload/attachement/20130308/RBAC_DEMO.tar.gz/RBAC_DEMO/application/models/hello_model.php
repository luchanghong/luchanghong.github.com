<?php 
class Hello_model extends CI_Model {

    var $uname     = '';
    var $email     = '';

    function __construct()
    {
        parent::__construct();
    }

    public function get_message_list()
    {
        $result = array();
        $this->load->database();
        $query = $this->db->get('message');
        foreach ($query->result() as $row)
        {
            $result[] = $row;
        }
        return $result;
    }

    public function insert_message()
    {
        $this->uname = $this->input->post('uname');
        $this->email = $this->input->post('email');
        $this->db->insert('message', $this);
        // echo 'ok';
    }
}
